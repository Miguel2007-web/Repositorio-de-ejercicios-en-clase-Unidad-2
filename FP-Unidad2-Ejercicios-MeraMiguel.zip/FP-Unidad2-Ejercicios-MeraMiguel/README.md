# FP-Unidad2-Ejercicios-MeraMiguel

**Nombre:** Miguel Mera
**NRC:** 37712
**Carrera:** Tecnología de la Información
**Materia:** Fundamentos de Programación B - Unidad 2
**Docente:** Ing. Esteban Gonzabay Jimenez Mgtr.

## Ejercicios

### S10 - Argumentos y parámetros
- [x] Ej01 - Intercambiar primitivos
- [x] Ej02 - Intercambiar arreglo
- [x] Ej03 - Aplicar descuento
- [x] Ej04 - Sobrecarga perimetro
- [x] Ej05 - Predicción de salida

### S11 - Ámbito de las variables
- [x] Ej01 - Marcar ámbito
- [x] Ej02 - Líneas que no compilan
- [x] Ej03 - Traza del contador static
- [x] Ej04 - Reescribir sin static

### S12 - Métodos de biblioteca
- [x] Ej01 - Distancia entre dos puntos
- [x] Ej02 - Dados que suman 7
- [x] Ej03 - Validar contraseña
- [x] Ej04 - Contar vocales
- [x] Ej05 - Generar código

Los 14 ejercicios están completos.
