/*
 * Sesión: S10 - Argumentos y parámetros: paso por valor
 * Ejercicio 01: Intercambiar primitivos
 * Enunciado: Escribe intercambiar(int a, int b) e intenta intercambiar
 * dos variables de main. ¿Funciona? Explica.
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

public class Ej01_IntercambiarPrimitivos {

    static void intercambiar(int a, int b) {
        int temp = a;
        a = b;
        b = temp;
    }

    public static void main(String[] args) {
        int x = 5;
        int y = 10;
        System.out.println("Antes: x = " + x + ", y = " + y);
        intercambiar(x, y);
        System.out.println("Despues: x = " + x + ", y = " + y);
    }
}

/*
 * ¿Funciona? No.
 * ¿Por qué? Java pasa los primitivos por valor: al llamar al método se copian
 * los valores de x e y en los parámetros a y b. El intercambio solo ocurre
 * en esas copias y, al terminar el método, desaparecen. Las variables x e y
 * de main nunca se tocan, por eso siguen valiendo 5 y 10.
 */
