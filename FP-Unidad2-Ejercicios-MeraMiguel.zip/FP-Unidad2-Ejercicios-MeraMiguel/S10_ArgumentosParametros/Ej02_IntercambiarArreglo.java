/*
 * Sesión: S10 - Argumentos y parámetros: paso por valor
 * Ejercicio 02: Intercambiar posiciones de un arreglo
 * Enunciado: Escribe intercambiar(int[] v, int i, int j) que intercambie
 * dos posiciones del arreglo. ¿Ahora sí?
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

import java.util.Arrays;

public class Ej02_IntercambiarArreglo {

    static void intercambiar(int[] v, int i, int j) {
        int temp = v[i];
        v[i] = v[j];
        v[j] = temp;
    }

    public static void main(String[] args) {
        int[] numeros = {4, 8, 15, 16, 23};
        System.out.println("Antes: " + Arrays.toString(numeros));
        intercambiar(numeros, 0, 4);
        System.out.println("Despues: " + Arrays.toString(numeros));
    }
}

/*
 * ¿Ahora sí? Sí funciona.
 * ¿Por qué? Lo que se copia al llamar al método es la referencia al arreglo,
 * no los elementos. Entonces v y numeros apuntan al mismo arreglo en memoria
 * y cuando el método cambia v[i] y v[j] está cambiando el arreglo original.
 */
