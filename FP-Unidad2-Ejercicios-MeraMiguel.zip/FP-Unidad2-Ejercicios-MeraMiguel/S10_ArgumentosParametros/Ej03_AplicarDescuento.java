/*
 * Sesión: S10 - Argumentos y parámetros: paso por valor
 * Ejercicio 03: Aplicar descuento a un arreglo de precios
 * Enunciado: aplicarDescuento(double[] precios, double pct) que modifique
 * todo el arreglo.
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

import java.util.Arrays;

public class Ej03_AplicarDescuento {

    static void aplicarDescuento(double[] precios, double pct) {
        for (int i = 0; i < precios.length; i++) {
            precios[i] = precios[i] - precios[i] * pct / 100;
        }
    }

    public static void main(String[] args) {
        double[] precios = {100, 50, 20, 80};
        System.out.println("Precios antes: " + Arrays.toString(precios));
        aplicarDescuento(precios, 10);
        System.out.println("Precios despues: " + Arrays.toString(precios));
    }
}
