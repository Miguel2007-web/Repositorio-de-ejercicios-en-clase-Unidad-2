/*
 * Sesión: S10 - Argumentos y parámetros: paso por valor
 * Ejercicio 04: Sobrecarga de perimetro
 * Enunciado: Sobrecarga perimetro(double lado) (cuadrado) y
 * perimetro(double a, double b) (rectángulo).
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

public class Ej04_SobrecargaPerimetro {

    static double perimetro(double lado) {
        return 4 * lado;
    }

    static double perimetro(double a, double b) {
        return 2 * (a + b);
    }

    public static void main(String[] args) {
        System.out.println("Perimetro del cuadrado: " + perimetro(5));
        System.out.println("Perimetro del rectangulo: " + perimetro(4, 2.5));
    }
}
