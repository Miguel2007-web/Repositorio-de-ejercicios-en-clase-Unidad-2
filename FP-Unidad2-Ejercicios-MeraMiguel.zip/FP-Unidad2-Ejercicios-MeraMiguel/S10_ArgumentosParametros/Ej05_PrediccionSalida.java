/*
 * Sesión: S10 - Argumentos y parámetros: paso por valor
 * Ejercicio 05: Predicción de salida
 * Enunciado: Predice en papel la salida de un programa con 3 llamadas
 * antes de ejecutarlo.
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

import java.util.Arrays;

public class Ej05_PrediccionSalida {

    static void modificar(int n, int[] v) {
        n = n + 5;
        v[0] = v[0] + n;
        System.out.println("Dentro: n = " + n + ", v[0] = " + v[0]);
    }

    public static void main(String[] args) {
        int n = 2;
        int[] v = {10, 20};
        modificar(n, v);
        modificar(n, v);
        modificar(n, v);
        System.out.println("Final: n = " + n + ", v = " + Arrays.toString(v));
    }
}

/*
 * Salida predicha:
 * Dentro: n = 7, v[0] = 17
 * Dentro: n = 7, v[0] = 24
 * Dentro: n = 7, v[0] = 31
 * Final: n = 2, v = [31, 20]
 *
 * n es un primitivo, así que en cada llamada se copia el 2 y el n de main
 * no cambia. v es un arreglo, así que el método modifica el mismo arreglo
 * y v[0] va subiendo 7 en cada llamada.
 */
