/*
 * Sesión: S11 - Ámbito de las variables
 * Ejercicio 01: Marcar ámbitos
 * Enunciado: Marca el ámbito de cada variable de un programa indicando
 * si es local, de bloque o static.
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

public class Ej01_MarcarAmbito {

    static int llamadas = 0;                 // static: vive toda la ejecucion
    static double iva = 0.15;                // static: la usan todos los metodos

    static double calcularTotal(double precio, int cantidad) {   // precio y cantidad: locales (parametros)
        llamadas++;
        double subtotal = precio * cantidad;                     // local: solo existe en calcularTotal
        double total = subtotal + subtotal * iva;                // local: solo existe en calcularTotal
        return total;
    }

    public static void main(String[] args) {
        double acumulado = 0;                                    // local de main
        for (int i = 1; i <= 3; i++) {                           // i: de bloque, solo existe en el for
            double costo = i * 10;                               // de bloque, solo existe en el for
            acumulado += calcularTotal(costo, i);
        }
        System.out.println("Total acumulado: " + acumulado);
        System.out.println("Llamadas: " + llamadas);
    }
}
