/*
 * Sesión: S11 - Ámbito de las variables
 * Ejercicio 02: Líneas que no compilan
 * Enunciado: Indica qué líneas no compilan y por qué.
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

public class Ej02_LineasNoCompilan {

    static int sumar(int a, int b) {
        int resultado = a + b;
        return resultado;
    }

    public static void main(String[] args) {
        int total = 0;
        for (int i = 1; i <= 3; i++) {
            total += sumar(i, 2);
        }
        // System.out.println(i);
        // Error: cannot find symbol. La variable i es de bloque y solo existe dentro del for.

        // System.out.println(resultado);
        // Error: cannot find symbol. resultado es local del metodo sumar y main no la ve.

        // int total = 5;
        // Error: variable total is already defined in method main(String[]). Ya se declaro total en el mismo ambito.

        // int promedio;
        // System.out.println(promedio);
        // Error: variable promedio might not have been initialized. Se usa una variable local sin darle valor.

        System.out.println("Total: " + total);
    }
}
