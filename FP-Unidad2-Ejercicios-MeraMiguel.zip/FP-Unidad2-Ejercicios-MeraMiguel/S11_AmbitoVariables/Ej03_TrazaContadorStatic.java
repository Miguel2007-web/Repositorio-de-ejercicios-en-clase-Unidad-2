/*
 * Sesión: S11 - Ámbito de las variables
 * Ejercicio 03: Traza del contador static
 * Enunciado: Haz la traza de un programa con un contador static llamado
 * desde un for.
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

public class Ej03_TrazaContadorStatic {

    static int contador = 0;

    static void contar(int paso) {
        contador = contador + paso;
    }

    public static void main(String[] args) {
        for (int i = 1; i <= 3; i++) {
            contar(i);
        }
        System.out.println("Contador: " + contador);
    }
}

/*
 * Traza (los números de línea son los de este archivo)
 *
 * linea | variables vivas      | valor
 * ------|----------------------|--------------------------------
 * 12    | contador             | contador = 0
 * 19    | contador, i          | contador = 0, i = 1
 * 20    | contador, i          | se llama contar(1)
 * 15    | contador, i, paso    | paso = 1, contador = 0 + 1 = 1
 * 19    | contador, i          | contador = 1, i = 2
 * 20    | contador, i          | se llama contar(2)
 * 15    | contador, i, paso    | paso = 2, contador = 1 + 2 = 3
 * 19    | contador, i          | contador = 3, i = 3
 * 20    | contador, i          | se llama contar(3)
 * 15    | contador, i, paso    | paso = 3, contador = 3 + 3 = 6
 * 19    | contador, i          | i = 4, la condición es falsa y el for termina
 * 22    | contador             | contador = 6 (i y paso ya no existen)
 *
 * Salida: Contador: 6
 */
