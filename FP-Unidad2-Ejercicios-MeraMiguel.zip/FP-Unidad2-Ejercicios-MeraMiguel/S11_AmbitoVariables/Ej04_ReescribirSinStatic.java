/*
 * Sesión: S11 - Ámbito de las variables
 * Ejercicio 04: Reescribir sin static
 * Enunciado: Reescribe un programa que usa 3 atributos static para que
 * use parámetros y return.
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

// Version original (con 3 atributos static)
/*
public class Ej04_ReescribirSinStatic {

    static double precio;
    static int cantidad;
    static double total;

    static void calcular() {
        total = precio * cantidad;
    }

    public static void main(String[] args) {
        precio = 2.5;
        cantidad = 4;
        calcular();
        System.out.println("Total: " + total);
    }
}
*/

// Version nueva (con parametros y return)
public class Ej04_ReescribirSinStatic {

    static double calcular(double precio, int cantidad) {
        return precio * cantidad;
    }

    public static void main(String[] args) {
        double precio = 2.5;
        int cantidad = 4;
        double total = calcular(precio, cantidad);
        System.out.println("Total: " + total);
    }
}
