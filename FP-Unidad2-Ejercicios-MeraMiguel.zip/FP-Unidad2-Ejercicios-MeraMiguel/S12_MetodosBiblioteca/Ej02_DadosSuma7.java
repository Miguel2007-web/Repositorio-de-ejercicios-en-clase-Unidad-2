/*
 * Sesión: S12 - Métodos de biblioteca
 * Ejercicio 02: Dados que suman 7
 * Enunciado: Lanzar dos dados 1000 veces y contar cuántas veces suman 7
 * (Random). Mostrar el conteo y el porcentaje.
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

import java.util.Random;

public class Ej02_DadosSuma7 {

    public static void main(String[] args) {
        Random azar = new Random();
        int lanzamientos = 1000;
        int cuenta = 0;

        for (int i = 0; i < lanzamientos; i++) {
            int dado1 = azar.nextInt(6) + 1;
            int dado2 = azar.nextInt(6) + 1;
            if (dado1 + dado2 == 7) {
                cuenta++;
            }
        }

        double porcentaje = cuenta * 100.0 / lanzamientos;
        System.out.println("Lanzamientos: " + lanzamientos);
        System.out.println("Veces que sumaron 7: " + cuenta);
        System.out.println("Porcentaje: " + porcentaje + "%");
    }
}
