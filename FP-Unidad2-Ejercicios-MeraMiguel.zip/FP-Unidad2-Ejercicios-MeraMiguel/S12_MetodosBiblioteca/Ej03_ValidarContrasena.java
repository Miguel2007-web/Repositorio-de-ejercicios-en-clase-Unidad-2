/*
 * Sesión: S12 - Métodos de biblioteca
 * Ejercicio 03: Validar una contraseña
 * Enunciado: Validar una contraseña: mínimo 8 caracteres, al menos una
 * mayúscula y un dígito (Character).
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

public class Ej03_ValidarContrasena {

    static boolean esValida(String clave) {
        if (clave.length() < 8) {
            return false;
        }
        boolean hayMayuscula = false;
        boolean hayDigito = false;
        for (int i = 0; i < clave.length(); i++) {
            char c = clave.charAt(i);
            if (Character.isUpperCase(c)) {
                hayMayuscula = true;
            }
            if (Character.isDigit(c)) {
                hayDigito = true;
            }
        }
        return hayMayuscula && hayDigito;
    }

    public static void main(String[] args) {
        String[] claves = {"Espe2026", "espe2026", "ESPEabcd", "Ab1", "Santo2026Domingo"};
        for (int i = 0; i < claves.length; i++) {
            if (esValida(claves[i])) {
                System.out.println(claves[i] + " -> valida");
            } else {
                System.out.println(claves[i] + " -> no valida");
            }
        }
    }
}
