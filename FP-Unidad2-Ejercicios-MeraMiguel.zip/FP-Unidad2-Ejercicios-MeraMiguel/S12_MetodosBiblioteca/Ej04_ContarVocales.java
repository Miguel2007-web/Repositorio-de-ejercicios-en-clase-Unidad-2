/*
 * Sesión: S12 - Métodos de biblioteca
 * Ejercicio 04: Contar vocales
 * Enunciado: Contar las vocales de una frase usando String y Character,
 * contando mayúsculas y minúsculas.
 * Autor: Mera Miguel
 * Fecha: 17/11/2026
 */

public class Ej04_ContarVocales {

    static int contarVocales(String frase) {
        int total = 0;
        for (int i = 0; i < frase.length(); i++) {
            char c = Character.toLowerCase(frase.charAt(i));
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                total++;
            }
        }
        return total;
    }

    public static void main(String[] args) {
        String frase = "Universidad de las Fuerzas Armadas ESPE";
        System.out.println("Frase: " + frase);
        System.out.println("Vocales: " + contarVocales(frase));
    }
}
